from owlready2 import *
import sys

material = sys.argv[1]
tolerancia = float(sys.argv[2])

onto = get_ontology("machining_rules.ttl").load()

with onto:
    class Peça(Thing): pass
    class temMaterial(DataProperty): domain = [Peça]; range = [str]
    class temTolerancia(DataProperty): domain = [Peça]; range = [float]
    class podeUsarFerramenta(ObjectProperty): domain = [Peça]; range = [Thing]

    p = Peça("peca_web")
    p.temMaterial = material
    p.temTolerancia = tolerancia

    sync_reasoner()

for f in p.podeUsarFerramenta:
    print(f"Sugestão: pode usar ferramenta {f.name}")