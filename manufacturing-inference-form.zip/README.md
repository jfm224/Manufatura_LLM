# Manufacturing Inference Form

Este projeto demonstra uma integração entre formulário web (PHP) e inferência semântica (OWL + Python) para pré-triagem de processos de manufatura com base em materiais, tolerância e usinabilidade.

## Componentes

- **HTML + PHP**: Formulário de entrada e back-end
- **Python + Owlready2**: Inferência com base em regras OWL/SWRL
- **JSON e OWL**: Base técnica e regras
- **FreeBSD Jail ready**: Dependências listadas para ambientes isolados

## Licença

MIT — desenvolvido com auxílio do ChatGPT/OpenAI.

## Uso

1. Instale dependências conforme `requisitos_servidor.txt`
2. Acesse `form.html` pelo navegador
3. Envie dados e veja as sugestões de ferramentas

## Fontes

Ver `referencias_manufatura.txt`
