<?php
$material = $_POST["material"];
$tolerancia = $_POST["tolerancia"];
$comando = escapeshellcmd("python3 inferencia.py "$material" "$tolerancia"");
$output = shell_exec($comando);
echo "<pre>$output</pre>";
?>